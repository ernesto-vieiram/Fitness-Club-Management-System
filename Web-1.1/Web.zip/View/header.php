<html>
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wroclaw Gym</title>
    <link rel="icon" type="image/x-icon" href="Pictures/logo.ico">
    <link rel="stylesheet" href="iconos/font-awesome/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Contrail+One&display=swap" rel="stylesheet">
  </head>
  <body>
    <h1 class="gymTitle">Wroclaw Fitness</h1>
    <h2 class="gymDescription">“If you can’t outplay them, outwork them.”</h2>
        <section class="Struct">
            <header>
                <link rel="stylesheet" type="text/css" href=CSS/estilos.css>
                <link rel="icon" type="image/x-icon" href="Pictures/logo.ico">
            </header>
