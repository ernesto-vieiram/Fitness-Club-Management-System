<html>
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="Pictures/logo.ico">
    <link rel="stylesheet" type="text/css" href=CSS/estilos.css>
</head>
<body>
<?php include "MenuOption.php";
include "header.php";?>

<p>You are not registered.</p>
<a href="index.php?accio=registre" >Sign Up!</button></a>

</html>