<html>
<head>
    <meta charset="UTF-8">
    <title>Failed Login</title>
    <link rel="stylesheet" type="text/css" href=CSS/register.css>
    <link rel="icon" type="image/x-icon" href="Pictures/logo.ico">
</head>
<header>
    <?php include "MenuOption.php";
    include "header.php";
    ?>

<body>
    <p>You are not registered!</p>
</body>
