<?php
  include __DIR__."/../Model/BD.php";
  include __DIR__."/../View/AddCourse.php"
 ?>
