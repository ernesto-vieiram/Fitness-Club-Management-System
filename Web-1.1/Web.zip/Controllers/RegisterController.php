<?php
include __DIR__.'/../View/Register.php';

include __DIR__.'/../Model/BD.php';



//include __DIR__.'/../vista/registreAcabat.php';
?>
