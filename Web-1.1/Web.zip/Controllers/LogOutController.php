<?php
include __DIR__ .'/../View/LogOut.php';