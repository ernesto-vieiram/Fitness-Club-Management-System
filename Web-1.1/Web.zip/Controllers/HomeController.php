<?php
/**
 * Created by PhpStorm.
 * User: alber
 * Date: 21/01/2020
 * Time: 20:48
 */
//include __DIR__. '/../model/BD.php';
include __DIR__.'/../View/Home.php';