<?php

include __DIR__.'/../View/Contact.php';